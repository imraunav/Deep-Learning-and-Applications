The codes in this folder are for Deeplearning Assignment 3.
For each .py file, change the directory to the appropriate string on the local machine.
All the Optimizers have been programmed seperately. To get the models for each of the optimizers, run the codes by uncommenting the appropriate location in the respective codes.
For our trained models, visit - https://github.com/imraunav/Deep-Learning-and-Applications-CS671/tree/main/ProgrammingAssignment3
We have decided to not provide the models with this submission due to accumulated size being large. 

Packages required for running the codes are as follows,
- numpy
- tensorflow
- matplotlib
- pickle

For querries, please contact either of the group members at 
(Raunav Ghosh)t22104@students.iitmandi.ac.in
(Prashant Kulkarni)t22058@students.iitmandi.ac.in
(Sachin Bahuleyan)t22060@students.iitmandi.ac.in
