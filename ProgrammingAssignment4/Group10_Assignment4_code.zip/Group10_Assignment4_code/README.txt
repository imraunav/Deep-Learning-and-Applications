The codes in this folder are for Deeplearning Assignment 4.

Packages required for running the codes are as follows,
- tensorflow>=2.10
- numpy
- pandas
- matplotlib
- sklearn


For queries, please contact either of the group members at 
(Raunav Ghosh)t22104@students.iitmandi.ac.in
(Prashant Kulkarni)t22058@students.iitmandi.ac.in
(Sachin Bahuleyan)t22060@students.iitmandi.ac.in
